<?php
/*
File: kaki.php
Fungsi: Mengatur Tampilan bagian bawah
Auth: ShowCheap
*/

?>

</div>
<div id='copyright' title='Tentang Aplikasi Ini (Click Here!!)'>Copyright &copy; <?php echo date('Y'); ?> GagalKoding | sourcecodeaplikasigratis.blogspot.com</div>
</body>
</html>