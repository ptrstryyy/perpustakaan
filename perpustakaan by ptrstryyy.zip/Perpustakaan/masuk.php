<?php
session_start();
/*
File: masuk.php
Fungsi: Form untuk login.
Auth: ShowCheap
*/
if(file_exists("upgrade/index.php")){
    header('location: upgrade/index.php');
    exit(0);
}
require 'sistem/config.php';
$pencet=$_POST['tmbl'];
sambung();
if(isset($_SESSION['level'])){
   $sesi=$_SESSION['level'];    
    if(($sesi=='Admin' || $sesi=='Pustakawan')){
        header('location: index.php');
    }
}
$nama=mysql_real_escape_string($_POST['nama']);
$kunci=md5($_POST['kunci']);

?>
<html>
<head>
<title>Login | Library Paramount SMK Kiansantang</title>

<link href="./tampilan/bootstrap/css/login.css" rel="stylesheet">

<script src='./tampilan/jq.js' type='text/javascript'></script>
<script type='text/javascript'>
    $(document).ready(function(){
        $('#user').focus();
    })
</script>
<script type='text/javascript'>
    $(document).ready(function(){
       
            $.ajax({
                url:'run.php',
                success: function(data){
                    //$("#res").html(data);
                    
                }
            })
       
      });    
</script>

<style type="text/css">
body {
    background-color:black;
   background-image:url(asdf.png);
  }

.login {
    width: 240px;
    margin: 10% auto;
    background-color: white;
    border: 1px solid #999;
    border: 1px solid rgba(0, 0, 0, 0.3);
    -webkit-border-radius: 6px;
    -moz-border-radius: 6px;
    border-radius: 6px;
    outline: 0;
    -webkit-box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
    -moz-box-shadow: 0 3px 7px rgba(0,0,0,0.3);
    box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
    -webkit-background-clip: padding-box;
    -moz-background-clip: padding-box;
    background-clip: padding-box;

}

</style>
</head>    
<body>

<?php
if ($pencet != '' && $nama != '' && $kunci != ''){
    $s=mysql_query("SELECT * FROM tbl_pustakawan WHERE user='".$nama."' AND kunci='".$kunci."'");
    $c=mysql_num_rows($s);
    if($c == '1'){
      $t= mysql_fetch_array($s);
      $log=$t['login'];
      $log=$log+1;
      mysql_query("UPDATE tbl_pustakawan SET login='$log' WHERE user='$nama'");
      $_SESSION['nama']=$t['nama'];
      $_SESSION['level']=$t['level'];
      $_SESSION['uid']=$t['id'];
      catat($_SESSION['nama'],"Berhasil Login");
      //header('location: index.php');
      echo "<script>window.location='index.php'</script>";
      exit();
    }else{
        catat($nama,"Gagal Login");
        $script= "<script type='text/javascript'>";
        $script.="$('document').ready(function(){";
        $script.="$('#result').html('<p class=\'alert alert-error\'>Username dan Password tidak cocok !</p>');";
        $script.="})";
        $script.="</script>";
        echo $script;
    }
};
?>
<div class="lg-container">

    <img src="abcde.png" width="100" height="100"style="float:right" /> SMK Kiansantang Bandung

		<h1> Library Online</h1>
   
    <h5 align=""> Silahkan Masuk Terlebih Dahulu</h5>
		<form action="" id="lg-form" method="post">
			
			<div>
				<label for="username">Nama Akun</label>
				<input type="text" name="nama" id="username" placeholder="Nama Akun"/>
			</div>
			
			<div>
				<label for="password">Kata Sandi:</label>
				<input type="password" name="kunci" id="password" placeholder="Kata Sandi" />
			</div>
			
			<div>				
                                 <input id="login" type='submit' value='LOGIN' name='tmbl'>
			</div>
			
		</form>
		<div id="message"></div>
	</div>   
</body>    
</html>
